using System;
using System.IO;
using System.Linq;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace SketchQuickTools
{
    internal sealed class SketchCommands
    {
        private const int GroupId = 82041;
        private const int SelectCirclesId = 1;
        private const string GroupName = "草图快捷工具";
        private readonly ISldWorks app;
        private readonly ICommandManager manager;
        private bool ownsGroup;

        internal SketchCommands(ISldWorks app, ICommandManager manager)
        {
            if (manager == null)
                throw new ArgumentNullException("manager");
            this.app = app;
            this.manager = manager;
        }

        internal void Register()
        {
            RemoveStaleMenus();
            int error = 0;
            ICommandGroup group = manager.CreateCommandGroup2(GroupId, GroupName, GroupName,
                "对当前草图执行快捷操作", -1, false, ref error);
            if (group == null)
                throw new InvalidOperationException("创建命令组失败，接口返回 " + error + "。");
            ownsGroup = true;

            string iconDirectory = Path.GetDirectoryName(typeof(SketchCommands).Assembly.Location);
            var sizes = new[] { 20, 32, 40, 64, 96, 128 };
            string[] icons = Array.ConvertAll(sizes, size => Path.Combine(iconDirectory, "Circle" + size + ".png"));
            group.IconList = icons;
            group.MainIconList = icons;

            int index = group.AddCommandItem2("选中欠定义圆", -1, "选中当前二维草图中的欠定义整圆",
                "选中欠定义圆", 0, "SelectUnderdefinedCircles",
                "CanSelectUnderdefinedCircles", SelectCirclesId,
                (int)(swCommandItemType_e.swMenuItem | swCommandItemType_e.swToolbarItem));
            if (index < 0)
                throw new InvalidOperationException("创建选圆命令失败。");
            group.HasMenu = true;
            group.HasToolbar = true;
            if (!group.Activate())
                throw new InvalidOperationException("激活命令组失败。");
        }

        internal void Unregister()
        {
            if (ownsGroup)
            {
                manager.RemoveCommandGroup2(GroupId, true);
                RemoveStaleMenus();
            }
            ownsGroup = false;
        }

        private void RemoveStaleMenus()
        {
            var frame = app.IFrameObject();
            if (frame == null)
                return;

            // Runtime-only removal can leave Tools menu entries in SOLIDWORKS 2026 SP0.0.
            foreach (int kind in new[] { 0, 1, 2, 3 })
            {
                var items = frame.GetSubMenus(kind, "Tools") as object[];
                int count = items == null ? 0 : items.Count(item => string.Equals(item as string, GroupName, StringComparison.Ordinal));
                for (int index = 0; index < count; index++)
                {
                    if (!app.RemoveMenu(kind, GroupName, ""))
                        break;
                }
            }
        }
    }
}
